--------------------
Snippet: FormIt
--------------------
Author: Shaun McCormick <shaun@modx.com>

A form processing Snippet for MODx Revolution.

Official Documentation:
http://rtfm.modx.com/display/ADDON/FormIt