<?php

class msOptionRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'msOption';
    public $objectType = 'ms2_option';
    public $languageTopics = array('minishop2:default');
}

return 'msOptionRemoveProcessor';
