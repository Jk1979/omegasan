<?php
require_once (dirname(dirname(__FILE__)) . '/msorderstatus.class.php');
class msOrderStatus_mysql extends msOrderStatus {}