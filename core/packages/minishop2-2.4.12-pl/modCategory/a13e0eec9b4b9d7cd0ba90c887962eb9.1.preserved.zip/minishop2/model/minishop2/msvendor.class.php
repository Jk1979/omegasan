<?php
class msVendor extends xPDOSimpleObject {}