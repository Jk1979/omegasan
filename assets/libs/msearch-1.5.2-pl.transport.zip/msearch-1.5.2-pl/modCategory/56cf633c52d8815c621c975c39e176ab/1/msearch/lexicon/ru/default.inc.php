<?php
/**
 * Default Russian Lexicon Entries for mSearch
 *
 * @package msearch
 * @subpackage lexicon
 */
$_lang['mse.err_no_query'] = 'Задан пустой поисковый запрос';
$_lang['mse.err_min_query'] = 'Слишком короткий поисковый запрос';
$_lang['mse.err_no_results'] = 'Ничего не найдено';
$_lang['mse.err_no_morphy_dicts'] = 'Вы должны скачать словари phpMorphy с http://sourceforge.net/projects/phpmorphy/files/phpmorphy-dictionaries/ и распаковать в [[+morphy_path]]. Или просто отключите использование phpMorphy опцией &disablePhpMorphy=`1`.';
 
